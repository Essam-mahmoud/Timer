//
//  ViewController.swift
//  TimerApp
//
//  Created by Essam Mahmoud fathy on 9/22/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
import CoreData
class ViewController: UIViewController ,UITableViewDelegate , UITableViewDataSource{

    @IBOutlet weak var PauseButton: MyCusstomButton!
    @IBOutlet weak var TimerLable: UILabel!
    @IBOutlet weak var TasksViewConstrain: NSLayoutConstraint!
    @IBOutlet weak var MyTaskView: MyView!
    @IBOutlet weak var MyTableView: UITableView!
    @IBOutlet weak var MainView: MyView!
    @IBOutlet weak var StartConstrain: NSLayoutConstraint!
    var timer : Timer!
    var seconds :Int = 0
    var Resumetoggle : Bool = false
    var IsPressed :Bool = true
    var nametextfield : UITextField!
    var tasksMO = [NSManagedObject]()
    var Names = [String]()
    override func viewDidLoad() {
        super.viewDidLoad()
        MainView.layer.cornerRadius = 20
        MyTableView.delegate = self
        MyTableView.dataSource = self
    }
    
    
    @IBAction func TasksButtonAction(_ sender: MyCusstomButton) {
        // then show the tasks table view
        self.TasksViewConstrain.constant = 0
        UIView.animate(withDuration: 0.5, animations: {
            self.view.layoutIfNeeded()
        })
    }

    // function to start timer
    @IBAction func StartAction(_ sender: UIButton) {
        StartConstrain.constant = 0
        UIView.animate(withDuration: 0.5) {
            self.view.layoutIfNeeded()
        }
        RunTimer()
        
    }
    
    // function to return time as string
    func TimeString(time : TimeInterval) -> String{
        
        let H = Int(time)/3600
        let M = Int(time)/60 % 60
        let S = Int(time) % 60
        return String(format: "%02i:%02i:%02i", arguments: [H , M , S])
        
    }
    
    //function to update timer and update the lable by the time
    @objc func UpdateTime(){
        seconds += 1
        TimerLable.text = TimeString(time: TimeInterval(seconds))
    }
    // function to make the timer begine and call updatetime
    func RunTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(ViewController.UpdateTime), userInfo: nil, repeats: true)
    }

    @IBAction func StopAction(_ sender: UIButton) {
        timer.invalidate()
        seconds = 0
        TimerLable.text = TimeString(time: TimeInterval(seconds))
        PauseButton.setTitle("Start", for: .normal)
        AlertController()
        
    }
    
    
    // function to fetch data and put it in application
    @objc func FetchData() {
        // make requst to retrive data
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Tasks")
        do {
            let results =  try Context.fetch(request)
            tasksMO = results as! [NSManagedObject]
            for taskmo in tasksMO {
                Names.append(taskmo.value(forKey: "name") as! String)
                MyTableView.reloadData()
            }
        } catch{
            
        }
    }
    // function to add alert to my app
    func AlertController(){
        let alertCon = UIAlertController(title: "Write Your Task", message: "Enter Your Task Name", preferredStyle: .alert)
        alertCon.addTextField { (nametextfield) in
            nametextfield.placeholder = "Task Name"
            self.nametextfield = nametextfield
      
            let AlertAction = UIAlertAction(title: "Save", style: .default, handler: { (action) in
                self.saveDataToCoreData()
            })
        let AlertAction2 = UIAlertAction(title: "Cancel", style: .default, handler: nil)
        alertCon.addAction(AlertAction)
        alertCon.addAction(AlertAction2)
        self.present(alertCon, animated: true, completion: nil)
    }  }
    
    
    
    // function to save to core data in our application
    func saveDataToCoreData(){
        // intiate the table in entity
        let entity = NSEntityDescription.entity(forEntityName: "Tasks", in: Context)
        // make object that put the table in tasks
        let task = NSManagedObject(entity: entity!, insertInto: Context)
        // put the values to table in the name attribute
        task.setValue(nametextfield.text!, forKey: "name")
        do{
            // try to save data in database
            try Context.save()
            let AlertCon = UIAlertController(title: "Save", message: "Your task \(nametextfield.text!) was Saved", preferredStyle: .alert)
            let AlertAc = UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                // then show the tasks table view
                self.TasksViewConstrain.constant = 0
                UIView.animate(withDuration: 0.5, animations: {
                    self.view.layoutIfNeeded()
                })
            })
            AlertCon.addAction(AlertAc)
            // must write this to show the alarm
            self.present(AlertCon, animated: true, completion: nil)
            FetchData()
        } catch{
            let AlertConf = UIAlertController(title: "Error", message: "\(error)", preferredStyle: .alert)
            let AlertAc = UIAlertAction(title: "Ok", style: .default, handler: nil)
            AlertConf.addAction(AlertAc)
            self.present(AlertConf, animated: true, completion: nil)
        }
        
    }
    // function to hide the table view from screen
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if TasksViewConstrain.constant == 0 {
            TasksViewConstrain.constant = 360
            UIView.animate(withDuration: 0.2) {
                self.view.layoutIfNeeded()
            }
        }
    }
    // to delete from table view
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        return UITableViewCellEditingStyle.delete
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            Context.delete(tasksMO[indexPath.row])
            do{
                try Context.save()
                self.Names.remove(at: indexPath.row)
                MyTableView.deleteRows(at: [indexPath], with: .fade)
            }catch{
                print("Error")
            }
        }
    }
    // pause function button
    @IBAction func PauseAction(_ sender: UIButton) {
        if PauseButton.titleLabel?.text == "Pause"{
            IsPressed = true
            timer?.invalidate()
            PauseButton.setTitle("Resume", for: .normal)
        } else if PauseButton.titleLabel?.text == "Resume" || PauseButton.titleLabel?.text == "Start" {
           IsPressed = false
           PauseButton.setTitle("Pause", for: .normal)
           RunTimer()
        }
       
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = Names[indexPath.row]
        return cell
    }
    
   


}

