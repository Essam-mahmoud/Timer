//
//  MyView.swift
//  TimerApp
//
//  Created by Essam Mahmoud fathy on 9/22/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
@IBDesignable
class MyView: UIView {

    @IBInspectable var firstColor : UIColor = UIColor.clear {
        didSet{
            UpdateView()
        }
    }
    @IBInspectable var secondColor : UIColor = UIColor.clear {
        didSet{
            UpdateView()
        }
    }
    override class var layerClass: AnyClass {
        get{
            return CAGradientLayer.self
        }
    }
    func UpdateView (){
        let Layer = self.layer as! CAGradientLayer
        Layer.colors = [firstColor.cgColor, secondColor.cgColor]
    }

}
