//
//  MyCusstomButton.swift
//  TimerApp
//
//  Created by Essam Mahmoud fathy on 9/22/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
@IBDesignable
class MyCusstomButton: UIButton {
    @IBInspectable var BorderWidth : CGFloat = 0{
        didSet{
            self.layer.borderWidth = BorderWidth
        }
    }
    @IBInspectable var BorderColor : UIColor = UIColor.clear{
        didSet{
            self.layer.borderColor = BorderColor.cgColor
        }
    }
    @IBInspectable var CornorRadius : CGFloat = 0{
        didSet{
            self.layer.cornerRadius = CornorRadius
        }
    }
    override func layoutSubviews() {
        super.layoutSubviews()
        self.clipsToBounds = true
    }

    

}
